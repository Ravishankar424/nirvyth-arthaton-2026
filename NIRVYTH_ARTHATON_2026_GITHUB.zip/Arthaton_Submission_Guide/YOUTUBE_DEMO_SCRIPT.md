# Arthaton 2026 — YouTube Demo Video Guide & Script (< 5 Minutes)

> **Rule from Arthaton**: *"Your demo video must be a public or unlisted YouTube video (not private), under 5 minutes, showing your app actually working. Slides alone do not count."*

---

## ⏱️ Video Timeline (Target: ~3.5 to 4 Minutes)

| Time | Screen Action | Voiceover / What to Say |
| :--- | :--- | :--- |
| **0:00 - 0:45** | Start screen recording on your browser showing `http://127.0.0.1:8080`. | *"Hello Team Arthaton. This is Ravishankar Kushwaha presenting NIRVYTH, an autonomous AI-driven public safety and drone geospatial surveillance platform built for smart cities and crowded urban hubs. In dense public spaces like metro stations, festivals, or commercial plazas, crowd surges and security threats can escalate in minutes, while manual CCTV review takes 20 to 30 minutes. NIRVYTH turns aerial drone feeds into real-time, sub-second tactical intelligence."* |
| **0:45 - 1:30** | Hover over the top left video feed. Point out altitude (32.5m), speed, battery, and heading. Click **`Toggle Thermal / RGB`**. | *"First is our Aerial Ingestion Engine. The system streams video while parsing 10Hz flight telemetry including altitude, airspeed, battery, and gimbal pitch angles. By clicking 'Toggle Thermal / RGB', commanders can switch between daylight 4K optical and nocturnal radiometric thermal IR modes for tracking heat signatures."* |
| **1:30 - 2:15** | Move to the Biometric Watchlist section. Point out the civilian boxes and suspect box. Click **`Toggle DPDP Masking`**. | *"Second is our Angle-Invariant Face Recognition engine. Using 512-dimensional vector embeddings, the model identifies suspects from overhead 45-degree angles. Under the DPDP Act 2023, innocent civilians are automatically blurred on the edge to protect privacy, unmasking only verified watchlist warrants."* |
| **2:15 - 3:00** | Move to the right panel. Click **`Simulate Fight Scuffle`** then **`Simulate Crowd Surge`**. Watch density cross 4.5 persons/m². | *"Third is Live Law-and-Order Analytics. We can test an anomaly like a scuffle, which spikes our motion divergence score. Next, when a crowd bottleneck forms, density rises past 4.5 persons per square meter, triggering an automated Stampede Early Warning siren 14.5 seconds before fatal crush thresholds."* |
| **3:00 - 3:45** | Move to the central Leaflet map. Click **`DISPATCH NEAREST PATROL CAR`**. Show the dispatch notification card with ETA. | *"Fourth is Geospatial Intelligence. Using optical raycasting, camera pixels are mapped directly to real-world GPS coordinates within 2.2 meters. Clicking 'Dispatch Nearest Patrol Car' calculates the Haversine distance and routes the closest patrol vehicle with real-time ETA."* |
| **3:45 - 4:15** | Show the console or repo page. | *"The evaluation prototype runs on Python's built-in standard library with zero external pip dependencies for judges. Thank you Team Arthaton."* |

---

## 📹 How to Record and Upload:
1. Open OBS Studio or Loom and record your full screen.
2. Run `python run_app.py` and walk through the steps in the script.
3. Save the video and upload to **YouTube**.
4. Set Title: `Arthaton 2026 – NIRVYTH (Autonomous Public Safety & Drone AI)`
5. Under Visibility, select **Unlisted** (or Public).
6. Copy the video link to paste in your GitHub README and submission form.
